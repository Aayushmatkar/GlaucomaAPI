import tensorflow as tf
from tensorflow.keras.models import load_model
import os
import cv2
import numpy as np

model = load_model("imageclassifier-50e-V100.keras")
results_tst = {}
counter = 0
correct = 0
img_dir = 'val'


for root, dirnames, fnames in os.walk(img_dir):
	for fname in fnames:
		img = cv2.imread(os.path.join(root,fname))
		if img is not None:
			img_resized = tf.image.resize(img, (256,256))
			result = model.predict(np.expand_dims(img_resized/255,0))
			observed_res = round(result[0][0])
			expected_res = 0
			if 'test/1/' in os.path.join(root,fname):
				expected_res = 1
			if expected_res == observed_res:
				correct += 1
	    		#print(os.path.join(root, fname))
			counter += 1

print(f"{correct}/{counter}")
